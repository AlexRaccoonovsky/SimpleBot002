created:{{date:YYYY-MM-DD}} {{time:HH:mm}}
status: #status/active 
references: 
___
> For what this info?: 
> How can use?
> Where Can Use? 
> When Can Use?

___
# {{title}}

## See also