KnownAs: Nickname
IMAGE: 
Social:blog, linkedin, twitter
KnownFor: 
WorkExperienceAreas; 
KnownWorks