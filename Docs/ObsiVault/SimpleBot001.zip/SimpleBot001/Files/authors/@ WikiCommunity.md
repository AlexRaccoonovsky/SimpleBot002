KnownAs: Wiki
IMAGE: ![[Pasted image 20210612171751.png]]
Social: https://en.wikipedia.org/

KnownFor: 
WorkExperienceAreas; 
KnownWorks