created:2021-06-25 02:47
status: #status/backlog 
references: 
___
> For what this info? Stage of designing.
> How can use? Stage of designing.v
> Where Can Use? Stage of designing.
> When Can Use? Stage of designing.

___
# Environment of SimpleBot001
![[Pasted image 20210625132623.png]]



## See also