KnownAs: StockSharpHelp, DocumentationStockSharp, ManualStockSharp...
IMAGE:  ![[Pasted image 20210617212428.png]]
Social:https://doc.stocksharp.ru/;
https://doc.stocksharp.com/
KnownFor: 
WorkExperienceAreas. 
KnownWorks: