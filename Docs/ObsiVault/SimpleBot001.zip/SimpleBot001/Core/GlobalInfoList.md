tags: #type/globaltask 
created:2021-06-17 21:11
___
_List Of  Shot Info Notes_:
**Deployment:**
[ ] 
 
**Conclusion:**
> Result?:
> Why?:
> Next steps?
