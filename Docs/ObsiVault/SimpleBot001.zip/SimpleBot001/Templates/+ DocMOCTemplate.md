tag: #doc 
status: #status/going 
created:{{date:YYYY-MM-DD}} {{time:HH:mm}}

# {{title}}
##
##
##

