tag: #doc 
status: #status/going 
created:2021-06-18 16:58

# DesigningMOC
## 1. [[Environment of SimpleBot001]]
## 2. Subsytems of SimpleBot001
## 3. Forming of classes
## 4. Forming Data & Methods in Classes
## 5. Designing of methods


