created:2021-06-15 21:38
status: #status/going 
references: 
___
> For what this info? for Idea of SimpleTask001 structure.
> How can use?
> Where Can Use? 
> When Can Use? on the stage of documentation's deployment of project SimpleTask001.

___
# PrepareDrafts
[[Pasted image 20210615214117.png | Drafts]]


## See also