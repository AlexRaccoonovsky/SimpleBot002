tag: #doc 
status: #status/going 
created:2021-06-17 17:30

# PrecedentConditions
## Problem definition
Need to take bot created by using S#.API. Bot will be connect, find security, execute some orders for open & close deal.
## [[Requirements]]
Requirements can be present by DRAKON-scheme described bot's functionality.
## Architecture's view
