Structure of tags can be presented & devided by next groups:
by status:
#status/active; % note created just now;
#status/finished;
#status/going; %?May be for MOC notes; ContentInfo- notes
#status/backlog; %active notes after 4 days, but not finished 
#status/archive;
by content:
#content/article;
#content/video;
#content/book;
by type:
#type/dailytask;
#type/globaltask; %task of Project%
#type/idea;
#type/skills;
#type/knowledge;
#type/info;
by action's type:
#action/deployment;
#action/reposervice;
#action/constructing;
#action/designing;
#action/planning;
#action/learning;
#action/coding;
#action/communication;
#action/noting;
by documentation's parts
#doc