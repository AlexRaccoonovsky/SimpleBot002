tags: #content/article
sources: [[https://doc.stocksharp.ru/html/9feaabde-52ea-4562-a666-380ce49c6df6.htm]],
[[https://doc.stocksharp.ru/html/T_StockSharp_BusinessEntities_MarketDepth.htm]]
authors: [[@ StockSharpHelp]]
created:2021-06-17 21:20
status: #status/active 
references: 
___
For what this info?: Need for construction stage.
How can use? Like tool.
Where Can Use? Innards SimpleBot001.

___
# MarketDepthSS

## See also