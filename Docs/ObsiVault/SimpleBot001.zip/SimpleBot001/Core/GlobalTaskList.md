tags: #type/globaltask 
created:2021-06-15 21:33
___
_List Of Purpose_:
**Deployment:**
- [ ] 
- [ ] 
- [ ] 
- [ ] 
 **RepoService:**:
- [ ] 
- [ ] 
- [ ] 
- [ ] 
**Constructing:**
- [ ] Segregate Modules_001  (20 min)
- [ ] Segregate Modules_002  (20 min)
- [ ] Segregate Modules_003  (20 min)
- [ ] 
- [ ] 
- [ ] 
- [ ] 
**Designing:**
- [ ] Design structure (30min)
- [ ] Design structure (30min)
- [ ] Design structure (30min)
- [ ] 
- [ ] 
- [ ] 
- [ ] 
**Planning:**
- [ ] 
- [ ] 
- [ ] 
- [ ] 
**Learning:**
- [ ] MarketDepth class [[MarketDepthSS]]
- [x] S#.API->Examples->SampleConnection
- [ ] 
- [ ] 
- [ ] 
- [ ] 
**Coding:**
- [ ] 
- [ ] 
- [ ] 
- [ ] 
**Communication:**
- [ ] 
- [ ] 
- [ ] 
- [ ] 
**Noting:**
- [x] Structure Of Documentation (20 min)
- [ ] Structure Of Documentation (20 min)
- [ ] GlobalInfoList_RealUseful?
- [ ] Depict [[Environment of SimpleBot001]]
- [ ] Create DraftsMOC & Aadd [[DraftsTestConnector]]
- [ ] 
- [ ] 
- [ ] 

**Conclusion:**
> Result?:
> Why?:
> Next steps?
