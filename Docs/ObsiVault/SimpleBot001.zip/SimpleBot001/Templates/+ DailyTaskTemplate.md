tags: #type/dailytask 
created:{{date:YYYY-MM-DD}} {{time:HH:mm}}
related: [[DailyNotesMOC]]
___
Global Task List is [[GlobalTaskList | here.]]
_List Of Purposes_:
___
**Deployment:**
- [ ] 
- [ ] 
- [ ] 
- [ ] 
 ___
 **RepoService:**:
- [ ] 
- [ ] 
- [ ] 
- [ ] 
___
**Constructing:**
- [ ] 
- [ ] 
- [ ] 
- [ ] 
___
**Designing:**
- [ ] 
- [ ] 
- [ ] 
- [ ] 
___
**Planning:**
- [ ] 
- [ ] 
- [ ] 
- [ ] 
___
**Learning:**
- [ ] 
- [ ] 
- [ ] 
- [ ] 
___
**Coding:**
- [ ] 
- [ ] 
- [ ] 
- [ ] 
___
**Communication:**
- [ ] 
- [ ] 
- [ ] 
- [ ] 
___
**Noting:**
- [ ] 
- [ ] 
- [ ] 
- [ ] 
___
**Conclusion:**
> Result?:
> Why?:
> Next steps?:
